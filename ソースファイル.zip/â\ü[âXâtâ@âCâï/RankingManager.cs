﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class RankingManager : MonoBehaviour
{
    string[] ranking = { "ランキング1位のスコア", "ランキング2位のスコア", "ランキング3位のスコア", "ランキング4位のスコア", "ランキング5位のスコア" };
    string[] rankingName = { "ランキング1位の名前", "ランキング2位の名前", "ランキング3位の名前", "ランキング4位の名前", "ランキング5位の名前" };
    int[] rankingValue = new int[5];
    string[] rankingValueName = new string[5];
    string defaultName = "unknown";
    int myRank = -1;
    public int MyRank() { return myRank; }
    [SerializeField] EventSystem eventSystem;
    [SerializeField] TextMeshProUGUI[] rankingText;
    [SerializeField] TextMeshProUGUI outOfRankText;
    [SerializeField] TextMeshProUGUI[] rankingNameText;
    [SerializeField] TMP_InputField[] inputFields;
    [SerializeField] FadeBlinkScript[] rankingFB;
    [SerializeField] FadeBlinkScript outOfRankFB;
    [SerializeField] GameObject rankUI;
    [SerializeField] SelectButtons selectButtons;

    private void Start()
    {
        //ResetRanking(0, defaultName);
    }


    public void Active(bool _bool)
    {
        rankUI.SetActive(_bool);
    }

    // ランキングを表示
    public void DisplayRank(int score)
    {
        rankUI.SetActive(true);
        GetRanking();
        GetRankingName();
        myRank = SetRanking(score, defaultName);
        for (int i = 0; i < ranking.Length; i++)
        {
            rankingText[i].text = rankingValue[i].ToString();
            rankingNameText[i].text = rankingValueName[i];
            inputFields[i].gameObject.SetActive(false);
        }
        if (myRank == -1)
            outOfRankText.text = score.ToString();
    }

    // ランキング取得
    private void GetRanking()
    {
        for (int i = 0; i < ranking.Length; i++)
        {
            rankingValue[i] = PlayerPrefs.GetInt(ranking[i]);
        }
    }

    private void GetRankingName()
    {
        for (int i = 0; i < ranking.Length; i++)
        {
            rankingValueName[i] = PlayerPrefs.GetString(rankingName[i]);
        }
    }

    // ナンバー１のスコアを取得
    public int GetRankingNo1()
    {
        GetRanking();
        return (rankingValue[0]);
    }

    // ランキングをセット(戻り値はランクインしているか)
    private int SetRanking(int score, string name)
    {
        int tmpInt;
        string tmpString;
        int rank = -1;

        for (int i = 0; i < ranking.Length; i++)
        {
            if (score > rankingValue[i])
            {
                tmpInt = rankingValue[i];
                tmpString = rankingValueName[i];
                rankingValue[i] = score;
                rankingValueName[i] = name;
                score = tmpInt;
                name = tmpString;
                // ここでランクをrankに格納
                if (rank == -1)
                {
                    rank = i;
                }
            }
        }

        // PlayerPrefsにセーブ
        for (int i = 0; i < ranking.Length; i++)
        {
            PlayerPrefs.SetInt(ranking[i], rankingValue[i]);
            PlayerPrefs.SetString(rankingName[i], rankingValueName[i]);
        }

        if (rank != -1)
        {
            // ランクインしてたら
            // 圏外のテキストを非表示
            DisplayOutOfRank(false);
            // ランクを点滅させる
            rankingFB[rank].StartFadeBlinkCoroutine(FadeBlinkScript.ObjectFadeBlink.CanvasFade, 0f, 0f, 0.05f);
        }
        else
        {
            // 圏外のテキストを表示
            DisplayOutOfRank(true);
            outOfRankFB.StartFadeBlinkCoroutine(FadeBlinkScript.ObjectFadeBlink.CanvasFade, 0f, 0f, 0.05f);
        }
        return rank;
    }

    // ランク外のスコアを表示
    private void DisplayOutOfRank(bool _bool)
    {
        outOfRankText.gameObject.SetActive(_bool);
    }

    // ボタンからの関数
    public void InputNameActive()
    {
        var gameObject_IF = inputFields[myRank].gameObject;
        gameObject_IF.SetActive(true);
        EventSystem.current.SetSelectedGameObject(gameObject_IF);
        selectButtons.Active(false, myRank);
    }

    public void EndInputName()
    {
        var text_InputField = inputFields[myRank].text;
        rankingNameText[myRank].text = text_InputField;
        PlayerPrefs.SetString(rankingName[myRank], text_InputField);
        selectButtons.Active(true, myRank);
        inputFields[myRank].gameObject.SetActive(false);
    }

    // ランキングをリセット
    private void ResetRanking(int score, string name)
    {
        for (int i = 0; i < ranking.Length; i++)
        {
            score = score == 0 ? score : score + i;
            PlayerPrefs.SetInt(ranking[i], score);
            PlayerPrefs.SetString(rankingName[i], name);
        }
        PlayerPrefs.SetInt(ranking[0], 263);
    }
}
