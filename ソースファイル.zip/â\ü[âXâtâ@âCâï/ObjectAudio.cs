﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectAudio : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip[] clipAttack;

    public bool IsPlayingLoop { get; set; } = false;
    public void PlayClip(int index)
    {
        StopClipLoop();
        audioSource.PlayOneShot(clipAttack[index]);
    }

    public void PlayClipLoop(int index)
    {
        if (!IsPlayingLoop)
        {
            audioSource.loop = true;
            audioSource.Play();
            IsPlayingLoop = true;
        }
    }

    public void StopClipLoop()
    {
        if (IsPlayingLoop)
        {
            audioSource.loop = false;
            audioSource.Stop();
            IsPlayingLoop = false;
        }
    }
}
