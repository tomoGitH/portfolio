﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ButtonScript : MonoBehaviour
{
    [SerializeField] float rate;
    [SerializeField] float time;

    [SerializeField] EventSystem eventSystem;
    bool flagOnce = false;
    Coroutine coroutine;

    private void Update()
    {
        if (eventSystem.currentSelectedGameObject == this.gameObject && !flagOnce)
        {
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                this.transform.localScale = new Vector3(1, 1, 1);
            }
            coroutine = StartCoroutine(Behuge(true, rate, time));
            flagOnce = true;
        }
        else if (eventSystem.currentSelectedGameObject != this.gameObject && flagOnce)
        {
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                this.transform.localScale = new Vector3(1, 1, 1);
            }
            coroutine = StartCoroutine(Behuge(false, rate, time));
            flagOnce = false;
        }
    }

    private IEnumerator Behuge(bool _bool, float size, float time)
    {
        float rate_beHuge = (size - 1.0f) / (time / Time.deltaTime);
        float x;
        float y;
        float z;
        float stockLocalX = this.transform.localScale.x;
        float stockLocalY = this.transform.localScale.y;
        float stockLocalZ = this.transform.localScale.z;

        if (_bool)
        {
            while (this.transform.localScale.x <= stockLocalX * size)
            {
                x = this.transform.localScale.x * (1 + rate_beHuge) < stockLocalX * size
                    ? this.transform.localScale.x * (1 + rate_beHuge)
                    : stockLocalX * size;
                y = this.transform.localScale.y * (1 + rate_beHuge) < stockLocalY * size
                    ? this.transform.localScale.y * (1 + rate_beHuge)
                    : stockLocalY * size;
                z = this.transform.localScale.z * (1 + rate_beHuge) < stockLocalZ * size
                    ? this.transform.localScale.z * (1 + rate_beHuge)
                    : stockLocalZ * size;
                this.transform.localScale = new Vector3(x, y, z);
                yield return null;
            }
        }
        else
        {

            while (this.transform.localScale.x * size >= stockLocalX)
            {
                x = this.transform.localScale.x * (1 - rate_beHuge) > stockLocalX / size
                    ? this.transform.localScale.x * (1 - rate_beHuge)
                    : stockLocalX / size;
                y = this.transform.localScale.y * (1 - rate_beHuge) > stockLocalY / size
                    ? this.transform.localScale.y * (1 - rate_beHuge)
                    : stockLocalY / size;
                z = this.transform.localScale.z * (1 - rate_beHuge) > stockLocalZ / size
                    ? this.transform.localScale.z * (1 - rate_beHuge)
                    : stockLocalZ / size;
                this.transform.localScale = new Vector3(x, y, z);
                yield return null;
            }
        }
    }
}
