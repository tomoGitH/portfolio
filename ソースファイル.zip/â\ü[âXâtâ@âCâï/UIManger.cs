﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class UIManger : MonoBehaviour
{
    [SerializeField] GameObject hp;
    [SerializeField] GameObject score;
    [SerializeField] TextMeshProUGUI scoreText;
    [SerializeField] TextMeshProUGUI no1Text;
    [SerializeField] SelectButtons selectButtons;
    [SerializeField] TutorialUIManager tutorialUI;
    [SerializeField] RankingManager ranking;
    [SerializeField] OrderManager order;
    public void StateStart()
    {
        hp.SetActive(false);
        score.SetActive(false);
        selectButtons.Active(false, 0);
        ranking.Active(false);
        tutorialUI.DisplayTutorial(0);
        order.HideOrder();
    }

    public int StateGameStart()
    {
        int highScore = ranking.GetRankingNo1();
        hp.SetActive(true);
        score.SetActive(true);
        order.DisplayOrder("キノコをたくさんとろう！");
        no1Text.text = $"${highScore}";
        return highScore;
    }

    public void StateFirst()
    {
        order.DisplayOrder("にんげんだ！にげろ！");
    }

    public void StateSecond()
    {
        order.DisplayOrder("にんげんはだんだんふえてくよ！");
    }
    public void StateThird()
    {
        order.DisplayOrder("キノコをとるとじかんがかいふく");
    }

    public void StateForth()
    {
        order.DisplayOrder("$100ぶんとれるかな？");
    }
    public void StateFifth()
    {
        order.DisplayOrder("すごい！きみはりっぱなキノコハンターだ！");
    }
    public void StateSixth()
    {
        order.DisplayOrder("にんげん「もうそろそろ勘弁して...」");
    }

    public void StateHighScore()
    {
        order.DisplayOrder("きろくこうしん！");
    }

    public void AlertKeyboard()
    {
        order.DisplayOrder("キーボードで入力してね");
    }

    // 終わりの状態
    public void StateGameEnd(int score)
    {
        ranking.DisplayRank(score);
        selectButtons.Active(true, ranking.MyRank());
        ranking.Active(true);
        order.HideOrder();
    }

    public void LoadSceneArg(string s)
    {
        SceneManager.LoadScene($"Scenes/{s}");
    }

    public void DisplayScoreText(string s)
    {
        scoreText.text = s;
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#elif UNITY_STANDALONE
        UnityEngine.Application.Quit();
#endif
    }
}
