﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class OrderManager : MonoBehaviour
{
    [SerializeField] FadeBlinkScript fade;
    [SerializeField] TextMeshProUGUI text;
    [SerializeField] GameObject panel;

    Coroutine coroutine_fade;

    public void DisplayOrder(string s)
    {
        panel.SetActive(true);
        text.text = s;
        // コルーチン中なら止める
        if (coroutine_fade != null)
            coroutine_fade = fade.StopFadeCoroutine();
        // コルーチン開始
        //coroutine_fade = fade.StartFadeBlinkCoroutine(FadeBlinkScript.ObjectFadeBlink.CanvasFade);
        coroutine_fade = fade.StartFadeOutBlink(FadeBlinkScript.ObjectFadeBlink.CanvasFade, 10.0f);
    }

    public void HideOrder()
    {
        // コルーチン中なら止める
        if (coroutine_fade != null)
            coroutine_fade = fade.StopFadeCoroutine();
        panel.SetActive(false);
    }
}
