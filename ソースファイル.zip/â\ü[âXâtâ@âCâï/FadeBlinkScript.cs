﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeBlinkScript : MonoBehaviour
{
    [SerializeField] CanvasGroup group;
    [SerializeField] MeshRenderer meshRenderer;

    Coroutine coroutine;
    Coroutine coroutine2;

    public enum ObjectFadeBlink
    {
        CanvasFade,
        MeshRendererBlink
    }

    // コルーチン開始
    public Coroutine StartFadeBlinkCoroutine(ObjectFadeBlink objectFB, float vanishTime, float blinkInterval, float addAlpha)
    {
        if (objectFB == ObjectFadeBlink.CanvasFade)
            coroutine = StartCoroutine(FadeLoopCanvas(addAlpha));
        else if (objectFB == ObjectFadeBlink.MeshRendererBlink && this.gameObject.activeSelf)
            coroutine = StartCoroutine(BlinkLoopMeshRenderer(vanishTime, blinkInterval));
        return coroutine;
    }

    // コルーチンを止める
    public Coroutine StopFadeCoroutine()
    {
        StopCoroutine(coroutine);
        if (coroutine2 != null)
            StopCoroutine(coroutine2);
        return null;
    }

    public Coroutine StartFadeOutBlink(ObjectFadeBlink objectFB, float time)
    {
        if (objectFB == ObjectFadeBlink.CanvasFade)
            coroutine = StartCoroutine(FadeOutBlink(time));
        return coroutine;
    }

    IEnumerator FadeOutBlink(float time)
    {
        float addAlpha = 0.01f;

        group.alpha = 1f;
        coroutine2 = StartCoroutine(FadeLoopCanvas(addAlpha));
        yield return new WaitForSeconds(time);
        StopCoroutine(coroutine2);
        while (group.alpha > 0.01f)
        {
            group.alpha -= addAlpha;
            yield return null;
        }

    }

    // フェードコルーチン
    IEnumerator FadeLoopCanvas(float addAlpha)
    {
        bool flag = false;
        while (true)
        {
            if (!flag && (group.alpha > 0.95f || group.alpha < 0.05f))
            {
                addAlpha *= -1;
                flag = true;
            }
            else if (flag && (group.alpha < 0.95f && group.alpha > 0.05f))
            {
                flag = false;
            }
            group.alpha += addAlpha;
            yield return null;
        }
    }

    IEnumerator BlinkLoopMeshRenderer(float vanishTime, float blinkInterval)
    {
        float countTime = 0f;

        while (true)
        {
            if (countTime > vanishTime)
                break;
            meshRenderer.enabled = (!meshRenderer.enabled);
            yield return new WaitForSeconds(blinkInterval);
            countTime += blinkInterval;
        }
        if (!meshRenderer.enabled)
            meshRenderer.enabled = true;
    }
}
