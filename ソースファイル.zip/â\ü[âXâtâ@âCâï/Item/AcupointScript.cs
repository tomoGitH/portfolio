﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AcupointScript : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player")
            if (collision.gameObject.GetComponent<PlayerController>().IsRolling())
            {
                Destroy(this.gameObject);
            }
    }
}
