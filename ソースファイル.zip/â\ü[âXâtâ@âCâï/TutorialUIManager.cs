﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialUIManager : MonoBehaviour
{
    [SerializeField] Tutorial tutorial;
    [SerializeField] FadeBlinkScript fade;
    const int PAGE_SIZE = 3;
    [SerializeField] GameObject[] page = new GameObject[PAGE_SIZE];
    public int Page_size_turtorial() { return PAGE_SIZE; }

    // フェードのコルーチンの状態
    Coroutine coroutine_fade;
    public void DisplayTutorial(int index)
    {
        HideTutorial();
        page[index].SetActive(true);
        // コルーチン中なら止める
        if (coroutine_fade != null)
            coroutine_fade = fade.StopFadeCoroutine();
        // コルーチン開始
        coroutine_fade = fade.StartFadeBlinkCoroutine(FadeBlinkScript.ObjectFadeBlink.CanvasFade, 0f, 0f, 0.01f);
    }
    public void HideTutorial()
    {
        for (int i = 0; i < page.Length; i++)
        {
            page[i].SetActive(false);
        }
    }

}
