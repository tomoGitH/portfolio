﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial : MonoBehaviour
{
    [SerializeField] TutorialUIManager uIManger;
    [SerializeField] GameController gameController;
    [SerializeField] MeshRenderer meshRenderer;
    [SerializeField] ObjectAudio audioPlayer;
    int state_pages = 0;

    Vector3[] pos = new Vector3[]
    {
        new Vector3(0, -0.5f, 10f),
        new Vector3(5, -0.5f, -5),
        new Vector3(-5, -0.5f, -5)
    };

    public int Page(){return state_pages;}

    private void Start()
    {
        meshRenderer.enabled = false;
        this.transform.position = pos[state_pages];
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            if (state_pages < uIManger.Page_size_turtorial() - 1)
            {
                audioPlayer.PlayClip(0);
                state_pages++;
                this.transform.position = pos[state_pages];
                uIManger.DisplayTutorial(state_pages);
                if (state_pages == uIManger.Page_size_turtorial() - 1)
                    meshRenderer.enabled = true;
            }
            else
            {
                if (collision.gameObject.GetComponent<PlayerController>().IsRolling())
                {
                    gameController.StartGame();
                    uIManger.HideTutorial();
                    this.gameObject.SetActive(false);
                }
            }
        }
    }
}
