﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct ItemColor
{
    public string colorName;
    public int score;
    public int percent;
}
