﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemScript : MonoBehaviour
{
    const float TIME_GEN_MAX = 4.0f; //さっき6
    const float TIME_GEN_MIN = 1.0f; //2
    const int SCORE_YELLOW = 1;
    const int SCORE_RED = 5;
    const int SCORE_BLUE = -10;
    const float AREA_WIDTH = 36.0f;
    const float AREA_HEIGHT = 36.0f;

    private GameController gameController;
    private MeshRenderer meshRenderer;
    private BoxCollider boxCollider;
    private Animator animator;
    [SerializeField] private Particle_Vanish particle_Vanish;
    [SerializeField] private Particle_Orb particle_Orb;
    [SerializeField] private Particle_Hit particle_Hit;

    [SerializeField] Material[] material;

    private int score;
    public int Score(){ return score; }
    private string colorName;

    public Dictionary<string, int> Color = new Dictionary<string, int>();
    Coroutine coroutine;

    private void Start()
    {
        gameController = GameObject.FindWithTag("GameController").GetComponent<GameController>();
        meshRenderer = this.GetComponent<MeshRenderer>();
        boxCollider = this.GetComponent<BoxCollider>();
        animator = this.GetComponent<Animator>();

        // 100分率で初期化
        Color.Add("Yellow", 70);
        Color.Add("Red", 25);
        Color.Add("Blue", 5);
        StartCoroutine(GenGrowUp());
    }
    public void Collision()
    {
        // キノコにヒットしたら
        particle_Hit.Play();
        // 衰退コルーチンを止める
        StopCoroutine(coroutine);
        // 生成＆成長コルーチンを始める
        StartCoroutine(GenGrowUp());
    }

    // 生成＆成長コルーチン
    IEnumerator GenGrowUp()
    {
        // 乱数（成長時間、出現場所）を取得
        var time = Random.Range(TIME_GEN_MIN, TIME_GEN_MAX);
        var posX = Random.Range((-1) * AREA_WIDTH / 2, AREA_WIDTH / 2);
        var posY = -0.5f;
        var posZ = Random.Range((-1) * AREA_HEIGHT / 2, AREA_HEIGHT / 2);
        var pos = new Vector3(posX, posY, posZ);
        // レンダラー、コライダー非アクティブ
        meshRenderer.enabled = false;
        Enable(false);

        // 予備時間
        yield return new WaitForSeconds(time);

        // レンダラーをアクティブ、発芽、ポジショニング、オーブを出す、スコアを付ける
        meshRenderer.enabled = true;
        animator.Play("Child");
        this.transform.position = pos;
        particle_Orb.Play();
        Initialize(Color["Yellow"] + Color["Red"] + Color["Blue"]);

        // 成長時間差はランダム
        yield return new WaitForSeconds(time / 2.0f);

        // アクティブ、成長、オーブを止める、枯れる段階に
        Enable(true);
        animator.Play("GrowUp");
        particle_Orb.Stop();
        coroutine = StartCoroutine(Wither(time));
    }

    // 衰退コルーチン
    IEnumerator Wither(float time)
    {
        float countTime = 0f;
        float blinkTime = 0.2f;
        float vanishTime = 3.0f;

        // 一定時間後に再生成
        yield return new WaitForSeconds(time + 5.0f);

        while (true)
        {
            if (countTime > vanishTime)
                break;
            meshRenderer.enabled = (!meshRenderer.enabled);
            yield return new WaitForSeconds(blinkTime);
            countTime += blinkTime;
        }

        particle_Vanish.Play();

        StartCoroutine(GenGrowUp());
    }

    // 表示非表示
    void Enable(bool isEnabled)
    {
        this.boxCollider.enabled = isEnabled;
    }

    // 初期化
    void Initialize(int percent)
    {
        // 乱数取得
        var randomIndex = Random.Range(0, percent);

        // マテリアルを配列単位で代入
        var tmp_materials = meshRenderer.materials;
        
        // 乱数で取得した色によって値を変更
        if (randomIndex > (percent -= Color["Yellow"]))
        {
            tmp_materials[1] = material[0];
            score = SCORE_YELLOW;
        }
        else if (randomIndex > (percent -= Color["Red"]))
        {
            tmp_materials[1] = material[1];
            score = SCORE_RED;
        }
        else if (randomIndex > (percent -= Color["Blue"]))
        {
            tmp_materials[1] = material[2];
            score = SCORE_BLUE;
        }
        
        // 描画
        meshRenderer.materials = tmp_materials;
    }
}
