﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle_Charge : MonoBehaviour
{
    [SerializeField]
    private ParticleSystem[] particles;

    public void Play()
    {
        foreach (var particle in particles)
        {
            particle.Play();
            particle.gameObject.SetActive(true);
        }
    }

    public void Stop()
    {
        foreach (var particle in particles)
        {
            particle.Stop();
            particle.gameObject.SetActive(false);
        }
    }
}
