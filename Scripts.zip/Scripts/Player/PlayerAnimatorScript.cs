﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimatorScript : MonoBehaviour
{
    [SerializeField] ObjectAudio objectAudio;
    public void Player_Charge(int index)
    {
        objectAudio.PlayClip(index);
    }

    public void CheckAudio()
    {
        if (objectAudio.IsPlayingLoop)
        {
            objectAudio.StopClipLoop();
        }
    }
}
