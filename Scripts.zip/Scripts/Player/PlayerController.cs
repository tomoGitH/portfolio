﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private GameController gameController; // ゲームコントローラー
    [SerializeField] private CameraController refCamera;    // カメラの水平回転を参照する用        
    [SerializeField] private Slider hpSlider;                    // HPスライダー

    [SerializeField] private Animator animator;                  // アニメーター
    [SerializeField] private Particle_Attack particle_Attack;    // パーティクル
    [SerializeField] private Particle_Charge particle_Charge;    // パーティクル
    [SerializeField] private LayerMask stageLayer;          // ステージのレイヤー
    [SerializeField] private ObjectAudio audioPlayer;
    [SerializeField] private FadeBlinkScript blink;

    private Vector3 pos_Init = new Vector3(0, 0, -15);
    private Vector3 velocity;                   // 移動方向
    private float moveSpeed = 17.0f;             // 移動速度
    private float applySpeed = 0.2f;            // 振り向きの適用速度
    private float jumpPower = 8.0f;             // ジャンプ力
    private Rigidbody rb;                       // 重力
    private bool isRolling;                     // 転がり状態かどうか
    private float attackPower;                  // 推進力
    private float time;                           // Time
    private float timeMax = 100;                  // TimeMAX

    public bool IsRolling() { return this.isRolling; }

    private void Awake()
    {
        rb = this.gameObject.GetComponent<Rigidbody>();
    }

    void Start()
    {
        Initialize();
    }

    private void Initialize()
    {
        time = timeMax;
        UpdateSlider(time);
        transform.position = pos_Init;
    }

    void Update()
    {
        // WASD入力から、XZ平面(水平な地面)を移動する方向(velocity)を得ます
        velocity = Vector3.zero;
        velocity.x = Input.GetAxis("Horizontal");
        velocity.z = Input.GetAxis("Vertical");
        if (Input.GetButtonUp("Jump") && IsGround())
        {
            // AttackPowerが一定以上あったら攻撃
            if (attackPower > 0.1f && isRolling == false)
                StartCoroutine(Attack());
            // 一定未満ならジャンプ
            //else
                //rb.velocity += Vector3.up * jumpPower;
        }

        // 速度ベクトルの長さを1秒でmoveSpeedだけ進むように調整します
        velocity = velocity.normalized * moveSpeed * Time.deltaTime;

        // 浮遊状態なら抵抗を空気抵抗を増やす
        rb.drag = animator.GetCurrentAnimatorStateInfo(0).IsName("Base Layer.Float") || isRolling ? 10.0f : 0f;

        // 伸長状態なら攻撃力を貯める
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Base Layer.Strech"))
        {
            attackPower = attackPower + 0.1f;
            particle_Charge.Play();
        }
        else
        {
            attackPower = 0f;
            particle_Charge.Stop();
        }

        // 空中状態
        if (!IsGround())
        {
            //if (Input.GetButton("Jump"))
            //    animator.Play("Float");
            //else
                animator.Play("Jump");
        }

        // いずれかの方向に移動している場合 ( 伸長状態、転がり状態を除く )
        if (velocity.magnitude > 0 && !(Input.GetButton("Jump") && IsGround()) && !isRolling)
        {
            if (IsGround())
                animator.Play("Move");

            MoveFront();
        }
        // 静止している時
        else if (IsGround())
        {
            if (Input.GetButton("Jump") && isRolling == false)
            {
                if (Input.GetAxis("Horizontal") > 0.5f || Input.GetAxis("Horizontal") < -0.5f
                    || Input.GetAxis("Vertical") > 0.5f || Input.GetAxis("Vertical") < -0.5f)
                {
                    animator.Play("Strech");
                    if (!audioPlayer.IsPlayingLoop)
                        audioPlayer.PlayClipLoop(2);
                    LookFront();
                }
                else
                {
                    animator.Play("Charge");
                }
            }
            else if (!isRolling)
            {
                    // アイドル時
                animator.Play("Idle");
            }
        }
    }

    // ジャンプ中かどうか
    bool IsGround()
    {
        RaycastHit hit;

        var origin = transform.position;
        var direction = Vector3.down * 2;
        var ray = new Ray(origin, direction);
        var maxDistance = 1.0f;

        if (Physics.Raycast(ray, out hit, maxDistance, stageLayer))
            return true;
        return false;
    }

    // 前に動く
    void MoveFront()
    {
        LookFront();

        // プレイヤーの位置(transform.position)の更新
        // カメラの水平回転(refCamera.hRotation)で回した移動方向(velocity)を足し込みます
        transform.position += refCamera.HRotation() * velocity;
    }

    // 前を見る
    void LookFront()
    {
        // プレイヤーの回転(transform.rotation)の更新
        // 無回転状態のプレイヤーのZ+方向(後頭部)を、
        // カメラの水平回転(refCamera.hRotation)で回した移動の反対方向(-velocity)に回す回転に段々近づけます
        transform.rotation = Quaternion.Slerp(transform.rotation,
                                              Quaternion.LookRotation(refCamera.HRotation() * -velocity),
                                              applySpeed);
    }

    // 攻撃
    IEnumerator Attack()
    {
        // 回転する
        isRolling = true;

        // 攻撃の音
        audioPlayer.PlayClip(0);

        // アニメーションを再生
        animator.Play("Attack");

        // 加速度
        attackPower = 200.0f;

        // 攻撃速度
        float x = (refCamera.HRotation() * velocity).x * attackPower;
        float z = (refCamera.HRotation() * velocity).z * attackPower;

        // 攻撃のパーティクルを表示
        particle_Attack.Play();

        // Rigidbody.AddForceで計算結果を代入
        rb.AddForce(x, 0, z, ForceMode.Impulse);

        // 一定時間待機
        yield return new WaitForSeconds(0.6f);

        // 回転を止める
        isRolling = false;

        attackPower = 0f;
    }

    public void AddPassTime(float passTime)
    {
        time += passTime;
        if (time > timeMax)
            time = timeMax;
        UpdateSlider(time);
    }

    private void UpdateSlider(float _time)
    {
        hpSlider.value = _time;
        if (hpSlider.value <= 0)
            gameController.EndGame();
    }

    // 壁に当たったら跳ね返り
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Wall")
        {
            BounceBack();
        }
        else if (collision.gameObject.tag == "Mush" && isRolling)
        {
            // キノコを取得
            var mush = collision.gameObject.GetComponent<ItemScript>();
            mush.Collision();
            gameController.UpdateScore(mush.Score());
            // プレイヤーの処理
            animator.Play("Eat");
            audioPlayer.PlayClip(1);
            particle_Attack.Stop();       
        }
        else if (collision.gameObject.tag == "Enemy")
        {
            if (!isRolling)
                blink.StartFadeBlinkCoroutine(FadeBlinkScript.ObjectFadeBlink.MeshRendererBlink, 1.0f, 0.1f, 0f);
            else
                collision.gameObject.GetComponent<Enemy>().Bounce(rb.velocity);
        }
    }

    // 跳ね返る
    private void BounceBack()
    {
        velocity.x = rb.velocity.x;
        velocity.z = rb.velocity.z;

        transform.LookAt(-velocity);
    }
}