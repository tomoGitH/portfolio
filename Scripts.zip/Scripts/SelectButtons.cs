﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using UnityEngine;
using UnityEngine.UI;

public class SelectButtons : MonoBehaviour
{
    enum Name
    {
        Restart,
        Quit,
        Input
    }

    [SerializeField] Button[] buttons;
    [SerializeField] Button firstSelected;

    // アクティブ化
    public void Active(bool _bool, int rank)
    {
        for (int i = 0; i < buttons.Length; i++)
        {
            if (rank == -1 && i == (int)Name.Input)
                continue;
            buttons[i].gameObject.SetActive(_bool);
        }
        // アクティブ化された時のみ初期化
        if (_bool)
            SelectFirst();
    }

    // 選択ボタンの初期化
    private void SelectFirst()
    {
        firstSelected.Select();
    }
}
