﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;

public class GameController : MonoBehaviour
{
    const int POOL_NUMBER = 20;

    [SerializeField] private GameObject prefab_item;
    [SerializeField] PlayerController player;
    [SerializeField] GameObject enemy;
    [SerializeField] UIManger uIManager;

    GameObject[] item = new GameObject[POOL_NUMBER];

    private int score = 0;
    private int highScore;
    Coroutine coroutine;

    [SerializeField] int level = 0;
    [SerializeField] bool debugMode;
    // Start is called before the first frame update
    void Start()
    {
        uIManager.StateStart();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        if (debugMode)
        {
            if (Input.GetKeyDown(KeyCode.O))
                UpdateScore(8);
        }
    }

    public void StartGame()
    {
        highScore = uIManager.StateGameStart();
        UpdateScore(0);
        GenerateMush();
        coroutine = StartCoroutine(PassTime());
    }

    // スコアを更新
    public void UpdateScore(int addScore)
    {
        score += addScore;
        if (score < 0)
            score = 0;
        if (score >= highScore)
        {
            uIManager.StateHighScore();
            highScore = 9999; // 一回だけ読み込まれたい
        }
        uIManager.DisplayScoreText(score.ToString());

        UpdateLevel();
    }

    // レベル更新
    private void UpdateLevel()
    {
        float levelUpTime = 20.0f;
        int numberNextLevetUp = 5;
        if (score / numberNextLevetUp > level)
        {
            GenerateEnemy();
            level = score / numberNextLevetUp;
            player.AddPassTime(levelUpTime);
        }
    }

    // オブジェクトプールキノコを生成
    private void GenerateMush()
    {
        for (int i = 0; i < item.Length; i++)
            item[i] = Instantiate(prefab_item, new Vector3(0, 0, 0), Quaternion.identity);
    }

    // 敵生成
    private void GenerateEnemy()
    {
        Instantiate(enemy, new Vector3(0, 5, 0), Quaternion.identity);
    }

    public void EndGame()
    {
        StopCoroutine(coroutine);
        uIManager.StateGameEnd(score);
        player.gameObject.SetActive(false);
    }

    IEnumerator PassTime()
    {
        float time = 1.0f; // 減らす時間
        float duration = 1.0f; // 初期値
        float duration_min = 0.1f; // 最小値
        float duration_decay_rate = 0.5f; // 減衰する割合
        int storeLevel = -1; // 最初に必ずif文の中に入るような0未満の任意の値
        while (true)
        {
            // レベルアップしたら
            if (storeLevel < level)
            {
                storeLevel = level;
                if (level == 1)
                    uIManager.StateFirst();
                else if (level == 6)
                    uIManager.StateSecond();
                else if (level == 11)
                    uIManager.StateThird();
                else if (level == 16)
                    uIManager.StateForth();
                else if (level == 20)
                    uIManager.StateFifth();
                else if (level == 30)
                    uIManager.StateSixth();
                duration = Duration(duration, duration_min, duration_decay_rate);
            }
            yield return new WaitForSeconds(duration);
            player.AddPassTime(-time);
        }
    }

    private float Duration(float value_init, float value_min, float rate_decay)
    {
        float duration;
        float duration_n = 1 / (value_init - value_min) / rate_decay;
        // 反比例
        // ( y + n ) = 1 / a( x + m )
        float denominator = ((float)level + duration_n) * rate_decay; // 分母
        duration = value_min + (1 / denominator);
        return (duration);
    }
}
