﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PlayerLoop;

public class Enemy : MonoBehaviour
{
    // オブジェクト側で割り当て
    GameObject target;

    // プレハブ側で割り当て
    [SerializeField] Particle_Attack_Enemy particle_Attack;
    [SerializeField] ObjectAudio audio;
    private Rigidbody rb;
    private float duration = 2.0f;
    private float damageTime = 10.0f;

    private void Start()
    {
        target = GameObject.FindWithTag("Player");
        rb = GetComponent<Rigidbody>();
        StartCoroutine(Chase());
    }

    public IEnumerator Chase()
    {
        yield return null;
        while (true)
        {
            var pos = target.transform.position;
            yield return StartCoroutine(Look(pos));
            StartCoroutine(Emit(particle_Attack));
            yield return StartCoroutine(Jump(pos));
            yield return new WaitForSeconds(duration);
        }
    }

    // 目標地点を見る
    IEnumerator Look(Vector3 direction)
    {
        var rot_present = transform.eulerAngles.y;                                              // 現在のy角
        var rot_target = Quaternion.LookRotation(direction - transform.position).eulerAngles.y; // 結果のy角
        var velocity0 = 0f;                                                                     // 開始速度
        var time_rot = 0.5f;

        // 現在と結果のz角の差が 1°より大きい間繰り返す
        while (Mathf.Abs(Mathf.DeltaAngle(rot_target, rot_present)) > 1.0f)
        {
            // 現在のz角の更新
            rot_present = Mathf.SmoothDampAngle(rot_present, rot_target, ref velocity0, time_rot);
            transform.eulerAngles = new Vector3(0, rot_present, 0);

            // 1フレーム停止
            yield return null;
        }
    }

    // エフェクトを出す
    IEnumerator Emit(Particle_Attack_Enemy effect)
    {
        var particle = Instantiate<Particle_Attack_Enemy>(effect, this.transform.position, Quaternion.identity);
        yield return null;
        while (particle.IsEmitting())
            yield return null;
    }

    // 目標地点までジャンプ
    IEnumerator Jump(Vector3 direction)
    {
        var jumpTime = 1.5f;
        var vx = (direction - this.transform.position) / jumpTime;
        var vy = (-1) * Physics.gravity * (jumpTime / 2) ;
        var jumpDirection = vx + vy;
        // ジャンプ
        rb.AddForce(jumpDirection, ForceMode.VelocityChange);
        // ジャンプの音
        audio.PlayClip(0);
        yield return new WaitForSeconds(jumpTime);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            var player = collision.gameObject.GetComponent<PlayerController>();
            if (!player.IsRolling())
            {
                player.AddPassTime(-damageTime);
                audio.PlayClip(1);
            }
        }
        else if (collision.gameObject.tag == "Mush")
        {
            // キノコを取得
            var mush = collision.gameObject.GetComponent<ItemScript>();
            mush.Collision();
        }
    }

    public void Bounce(Vector3 direction)
    {
        direction.y = 10;
        direction = direction.normalized * 10;
        rb.AddForce(direction, ForceMode.VelocityChange);
    }
}
