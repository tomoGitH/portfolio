﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle_Attack_Enemy : MonoBehaviour
{
    [SerializeField] private ParticleSystem particle;

    private void Start()
    {
        StartCoroutine(Play());
    }
    IEnumerator Play()
    {
        particle.Play();
        while (particle.isEmitting)
            yield return null;
        Destroy(this.gameObject);
    }

    public bool IsEmitting()
    {
        if (particle.isEmitting)
            return true;
        else
            return false;
    }
}
